package com.predictionmarketing.Recommend;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.LogLikelihoodSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;

public class ItemRecommend {

	public static void main(String[] args) throws TasteException {

		try {
			
			
			// Chargement des don�es depius notre fichier movies.csv
			DataModel dm = new FileDataModel(new File("data/movies.csv"));
			
			// 	Construction des similarit�s entre les produits (items)
			ItemSimilarity sim = new LogLikelihoodSimilarity(dm);
			
			// Construction du recommandeur
			GenericItemBasedRecommender recommender = new GenericItemBasedRecommender(dm, sim);
			
			int x=1;
			
			// 'LongPrimitiveIterator' Un type de base pour les sp�cialisations primitives d'it�rateur. 
			// Des sous-types sp�cialis�s sont fournis pour les valeurs int, longues et doubles.
			
			for(LongPrimitiveIterator items = dm.getItemIDs(); items.hasNext();) {
				long itemId = items.nextLong();
				
				// 'recommendetions' est une liste d'au maximum 5 objets contenant un identifiant de film et un score
				List<RecommendedItem> recommendetions = recommender.mostSimilarItems(itemId, 5);
				
				for(RecommendedItem recommendation:recommendetions)
				{
					System.out.println(itemId+", "+recommendation.getItemID()+", "+recommendation.getValue());
				}
				x++;
				if(x>10) System.exit(1);
				
			}
			
		}catch(IOException e){
			
		}

	}

}
