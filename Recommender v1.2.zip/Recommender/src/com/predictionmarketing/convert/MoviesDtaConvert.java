package com.predictionmarketing.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MoviesDtaConvert {
	
	/*
	 * 
	 * cat u.data | cut f1,2,3 | tr "\\t"
	 */

	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader("data/u.data"));
		BufferedWriter bw = new BufferedWriter(new FileWriter("data/movies.csv"));
		
		String line; 
		while((line = br.readLine()) != null) {
			String[] valeus = line.split("\\t", -1);
			bw.write(valeus[0]+","+valeus[1]+","+valeus[2]+"\n");
		}
		
		br.close();
		bw.close();
		
		
	}

}
